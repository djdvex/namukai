import React, {useState, useEffect} from 'react'
import Auth from './components/Auth.jsx'
import Chat from './components/Chat.jsx'
import Plans from './components/Plans.jsx'
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnon = import.meta.env.VITE_SUPABASE_ANON_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
export const supabase = createClient(supabaseUrl, supabaseAnon)

export default function App(){
  const [user, setUser] = useState(null)

  useEffect(()=>{
    supabase.auth.getSession().then(r=>{ if(r.data?.session) setUser(r.data.session.user) })
    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      setUser(session?.user ?? null)
    })
    return ()=> listener?.subscription?.unsubscribe?.()
  },[])

  return (
    <div className="app-root">
      <header className="header">
        <div className="logo">
          <img src="/logo.svg" alt="DI Namams" style={{height:36,verticalAlign:'middle'}} />
          <span style={{marginLeft:10}}>DI Namams</span>
        </div>
        <div className="tag">Powered by OpenAI</div>
      </header>

      <main className="main">
        {!user ? <Auth supabase={supabase}/> : (
          <>
            <Plans supabase={supabase} user={user} />
            <Chat supabase={supabase} user={user} />
          </>
        )}
      </main>

      <footer className="footer">© DI Namams</footer>
    </div>
  )
}
