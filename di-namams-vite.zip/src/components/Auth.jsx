import React from 'react'

export default function Auth({supabase}){
  const signInWithGoogle = async ()=>{
    await supabase.auth.signInWithOAuth({provider:'google'})
  }

  const signUpEmail = async ()=>{
    const email = prompt('Įvesk el. paštą')
    if(!email) return
    await supabase.auth.signUp({email})
    alert('Patikrink el. paštą dėl prisijungimo nuorodos')
  }

  return (
    <div className="card">
      <h3>Prisijunk</h3>
      <div style={{display:'flex',gap:8}}>
        <button className="btn" onClick={signInWithGoogle}>Prisijungti su Google</button>
        <button className="btn" onClick={signUpEmail}>El. paštas</button>
      </div>
      <p style={{color:'var(--muted)',marginTop:12}}>Nemokamai 20 žinučių pradžiai</p>
    </div>
  )
}
